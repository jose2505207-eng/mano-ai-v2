import logging

from .base import BrowserProvider
from .playwright_provider import PlaywrightProvider
from .actionbook_provider import ActionbookProvider
from app.core.config import settings

logger = logging.getLogger(__name__)


class BrowserManager:
    """Manages browser provider selection and lifecycle.

    Resolution order:
      1. Actionbook — if ``browser_provider == "actionbook"`` and an API key
         is configured.
      2. Playwright — always available as the default fallback.
    """

    def __init__(self) -> None:
        self._provider: BrowserProvider | None = None

    async def get_provider(self) -> BrowserProvider:
        """Return the active provider, lazily initialising on first call."""
        if self._provider:
            return self._provider

        # Try Actionbook first if configured
        if settings.browser_provider == "actionbook" and settings.actionbook_api_key:
            try:
                provider = ActionbookProvider()
                await provider.launch()
                self._provider = provider
                logger.info("Using Actionbook browser provider")
                return provider
            except Exception as e:
                logger.warning(
                    f"Actionbook failed, falling back to Playwright: {e}"
                )

        # Default to Playwright
        provider = PlaywrightProvider()
        await provider.launch()
        self._provider = provider
        logger.info("Using Playwright browser provider")
        return provider

    async def close(self) -> None:
        """Shut down the active provider and release resources."""
        if self._provider:
            try:
                await self._provider.close()
            except Exception as e:
                logger.error(f"Error closing browser provider: {e}")
            finally:
                self._provider = None
